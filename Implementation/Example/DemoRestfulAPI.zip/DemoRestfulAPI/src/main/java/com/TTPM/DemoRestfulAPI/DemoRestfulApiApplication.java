package com.TTPM.DemoRestfulAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRestfulApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRestfulApiApplication.class, args);
	}

}
